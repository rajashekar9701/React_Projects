import { useNavigate } from "react-router-dom";
import React from "react";
// import { useAuth } from "../components/Auth";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

const Resume = () => {
  // const auth = useAuth();
  const navigate = useNavigate();
  const handleLogout = () => {
    // auth.logout();
    navigate("/");
  };
  return (
    <>
      <Navbar />
      <div>
      <h1>Resume</h1>
        {/* Resume Page {auth.user} */}
        <button onClick={handleLogout}>Logout</button>
      </div>
    </>
  );
};

export default Resume;
