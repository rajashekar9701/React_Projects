import { useNavigate } from "react-router-dom";
import React from "react";

import Navbar from "../components/Navbar";

const Todo = () => {
  // const auth = useAuth();
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.clear()
    navigate("/");
  };
  return (
    <>
      <Navbar />
      <div>
        {/* Todo Page {auth.user} */}
        <h1>TODO</h1>
        <button onClick={handleLogout}>Logout</button>
      </div>
    </>
  );
};

export default Todo;
