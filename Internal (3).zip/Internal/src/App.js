import React from "react";
import "./index.css";
import Home from "./routes/Home";
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import Resume from "./routes/Resume";
import Todo from "./routes/Todo";
import Login from "./routes/Login";
import Register from "./components/register";
import PersonalInfo from "./routes/PersonalInfo";
import { ToastContainer } from 'react-toastify';
import Logout from "./routes/logout";
import PrivateRoute from "./components/PrivateRoute";


function App() {
  return (
    <BrowserRouter>
     <ToastContainer></ToastContainer>

      <Routes>
        <Route path="/" element={<Home />}/>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register/>}/>
        <Route path='/logout' element={<Logout/>} />
        <Route path='/todo' element={<PrivateRoute component={Todo}/>}/>
        <Route path='/resume' element={<PrivateRoute component={Resume}/>}/>
        <Route path="/personalinfo" element={<PrivateRoute component={PersonalInfo}/>}/>
        </Routes>
        </BrowserRouter>
   
  );
}

export default App;
