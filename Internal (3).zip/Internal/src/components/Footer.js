import './Footer.css';
import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
       <p>Copyright</p>
    </div>
  )
}

export default Footer
