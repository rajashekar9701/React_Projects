import { useState } from "react";
import axios  from "axios";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Swal from "sweetalert2";
import draw2 from '../images/draw2.webp'

const Register=()=>{
    const [employeeId, employeeIdChange] = useState("");
    const [firstName, firstnamechange] = useState("");
    const [lastName, lastnamechange] = useState("");
    const [userPassword, passwordchange] = useState("");
    const [userName, userNameChange] = useState("");
    const navigate = useNavigate();

    const IsValidate = () => {
        let isproceed = true;
        let errormessage = 'Please enter the value in ';
        if (employeeId === null || employeeId === '') {
            isproceed = false;
            errormessage += ' Username';
        }
        if (firstName === null || firstName === '') {
            isproceed = false;
            errormessage += ' Firstname';
        }
        if (lastName === null || lastName === '') {
            isproceed = false;
            errormessage += ' Lastname';
        }
        if (userPassword === null || userPassword === '') {
            isproceed = false;
            errormessage += ' Password';
        }
        if (userName === null || userName === '') {
            isproceed = false;
            errormessage += ' Email';
        }

        if(!isproceed){
            toast.warning(errormessage)
        }else{
            if(/^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/.test(userName)){

            }else{
                isproceed = false;
                toast.warning('Please enter the valid email')
            }
        }
        return isproceed;
    }
    const handlesubmit=(e)=>{
        e.preventDefault();
        const registerObj={employeeId,firstName,lastName,userName,userPassword};
        if (IsValidate()) {
        axios.post("http://localhost:8080/registerNewUser", {
            employeeId:employeeId,
            firstName:firstName,
            lastName:lastName,
            userName:userName,
            userPassword:userPassword

            // {
            //     "employeeId": 44859,
            //     "firstName": "pavan",
            //     "lastName": "pavan",
            //     "userName": "pavan@gmail.com",
            //     "userPassword": "pavan@123"
            // }
           
        }).then((response)=>{
            Swal.fire('Registered successfully.')
            navigate('/login');
   
            //console.log(response.data);

        }).catch((err) => {
            toast.error('Failed :' + err.message);
        });
      
    }
    }
    return(
        <div>
        <div>
        <Navbar/>
        </div>
        <div className="row"
        style={{
     
             fontFamily:'Roboto',
              height: '100vh',
              margin: '0',
              paddingBottom:'20px',
              overflow:'auto',
              backgroundColor:'#04b1d9 ',
            //  backgroundRepeat:'no-repeat'
        }}>
         <div className="col-md-9 col-lg-6 col-xl-5" style={{marginTop: '80px' }}>
          <img src={draw2} className="img-fluid" alt="Sample image" />
        </div>
        <div className="col-md-8 col-lg-6 col-xl-4 offset-xl-2" style={{ marginTop: '100px'}}>
            <form className="container" onSubmit={handlesubmit}>
                <div className="card"  
                style={{boxShadow:'0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
                backgroundColor:'white'
                }}>
                    <div className="card-header" style={{fontWeight: 'lighter',fontSize:'5px'}}>
                        <h1> Register </h1>
                    </div>
                    <div className="card-body">
                       <div className="row">
                       <div className="col-lg-6">
                            <div className="form-group">
                                <label> Email <span className="errmsg">*</span></label>
                                <input type="text" value={userName} onChange={e => userNameChange(e.target.value)} className="form-control"></input>
                            </div>
                            </div>
                       
                            <div className="col-lg-6">
                            <div className="form-group">
                                <label>First Name <span className="errmsg">*</span></label>
                                <input type="text" value={firstName} onChange={e => firstnamechange(e.target.value)} className="form-control"></input>
                           
                            </div>
                            </div>
                            <div className="col-lg-6">
                            <div className="form-group">
                                <label>Last Name <span className="errmsg">*</span></label>
                                <input type="text" value={lastName} onChange={e => lastnamechange(e.target.value)} className="form-control"></input>
                              
                            </div>
                            </div>

                       
                            <div className="col-lg-6">
                            <div className="form-group">
                                <label>Employee Id <span className="errmsg">*</span></label>
                                <input value={employeeId} onChange={e => employeeIdChange(e.target.value)} type="text" className="form-control"></input>
                            </div>
                            </div>
                        
                            <div className="col-lg-6">
                            <div className="form-group">
                                <label>Password <span className="errmsg">*</span></label>
                                <input type="password" value={userPassword} onChange={e => passwordchange(e.target.value)} className="form-control"></input>
                            </div>
                            </div>
                       
                         </div>
                        
                    </div>
                    <div className="card-footer">
                    <button type="submit" className="btn btn-primary">Register</button>
                    <Link to={'/login'} className="btn btn-danger" style={{marginLeft:'8px'}}>Close</Link>
                        
                    </div>
                </div>
            </form>

            </div>
        </div>
        </div>
    )

}
export default Register;