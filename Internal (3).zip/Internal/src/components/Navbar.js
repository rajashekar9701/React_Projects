import { Link, useNavigate,Navigate } from "react-router-dom";
import "./NavbarStyles.css";
import React, { useEffect, useState } from "react";

import Tippy from "@tippyjs/react";
import "tippy.js/dist/tippy.css";

import {
  FaBars,
  FaTimes,
  FaHome,
  FaCheckCircle,
  FaUserAlt,
  FaBook,
  FaSignInAlt,
  FaSignOutAlt,
} from "react-icons/fa";



const Navbar = () => {
  const navigate = useNavigate();
  const [click, setClick] = useState("false");
  const handleClick = () => setClick(!click);
  const handleLogout = () => {
    localStorage.clear();
    // return <Navigate to={'/login'} />
    // auth.logout();
    navigate("/");
  };

  return (
    <div className="header">
      <Link to="/">
        <img
          className="logo"
          src="https://tse4.mm.bing.net/th/id/OIP.bTWaiIirNZvVO2UDJMBoHwAAAA?pid=ImgDet&rs=1"
        />
      </Link>
      <ul className={click ? "nav-menu active" : "nav-menu"}>
        <li className="nav-item ">
          <Tippy content="HOME">
            <Link to="/">
              <FaHome />
            </Link>
          </Tippy>
        </li>
        <li>
          <Tippy content="TODO">
            <Link to='/todo' onClick={(handleClick)}>
              <FaCheckCircle />
            </Link>
          </Tippy> 
          {/* <Todo isLoggedIn={this.props.isLoggedIn} /> */}
        </li>
        <li>
          <Tippy content="RESUME">
            <Link to="/resume" onClick={(handleClick)}>
              <FaBook />
            </Link>
          </Tippy>
        </li>
        <li>
          <Tippy content="PERSONAL INFO">
            <Link to="/personalinfo" onClick={(handleClick)}>
              <FaUserAlt />
            </Link>
          </Tippy>
        </li>
        <li>
          {localStorage.getItem('jwtToken') ==null && (
            <Tippy content="LOGIN">
              <Link to="/login" onClick={handleClick}>
                <FaSignInAlt />
              </Link>
            </Tippy>
          )}
          {localStorage.getItem('jwtToken') !=null && (
            <Tippy content="LOGOUT">
              <a onClick={handleLogout}>
                <FaSignOutAlt />
              </a>
            </Tippy>
          )}
        </li>
      </ul>
      <div className="hamburger" onClick={handleClick}>
        {click ? (
          <FaTimes size={20} style={{ color: "black" }} />
        ) : (
          <FaBars size={20} style={{ color: "black" }} />
        )}
      </div>
    </div>
  );
};

export default Navbar;
