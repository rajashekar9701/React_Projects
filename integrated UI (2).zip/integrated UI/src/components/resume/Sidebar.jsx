import React, { useState } from "react";
import './Sidebar.scss';
import {
  FaBars,
  FaFileUpload,
  FaFacebook,
  FaTwitter,
  FaLinkedin,
  FaGithub,
  FaFilePdf
} from "react-icons/fa";

import { NavLink } from "react-router-dom";
import MyImg from "../../images/profile.jpeg";

const Sidebar = ({ children }) => {
  const [isOpen, setIsOpen] = useState(true);
  const toggle = () => setIsOpen(!isOpen);
  const menuItem = [
    {
      path: "/uploadResume",
      name: "Upload Resume",
      icon: <FaFileUpload />,
    },
    {
      path: "/viewResume",
      name: "View Resume",
      icon: <FaFilePdf />,
    },
  ];

  const social_links = [
    {
      name: "linkedin",
      icon: <FaLinkedin />,
      link: "https://www.linkedin.com/feed/"
    },
    {
      name: "github",
      icon: <FaGithub />,
      link: "#"
    },
    {
      name: "facebook",
      icon: <FaFacebook />,
      link: "#"
    },
    {
      name: "twitter",
      icon: <FaTwitter />,
      link: "#"
    }
  ];

  const email = localStorage.getItem("email");
  const atIndex = email.indexOf('@');
  const username = email.substring(0, atIndex);

  return (
    <div className="resume-sidebar-container">
      <div style={{ width: isOpen ? "200px" : "50px" }} className="resume-sidebar">
        <div className="resume-top_section">
          <h6 style={{ display: isOpen ? "block" : "none" }} className="resume-logo">
            Resume
          </h6>
          <div style={{ marginLeft: isOpen ? "40px" : "0px" }} className="resume-bars">
            <FaBars onClick={toggle} />
          </div>
        </div>
        <div
          className="resume-mid_section"
          style={{ display: isOpen ? "flex" : "none" }}
        >
          <img className="resume-profile_pic" src={MyImg} alt="" />
          <p className="resume-username">{username}</p>
        </div>

        {menuItem.map((item, index) => (
          <NavLink to={item.path} key={index} className="resume-link">
            <div className="resume-icon">{item.icon}</div>
            <div
              style={{ display: isOpen ? "block" : "none" }}
              className="resume-link_text"
            >
              {item.name}
            </div>
          </NavLink>
        ))}

        <div className="resume-social-links">
          {social_links.map((item, index) => (
            <a href={item.link} target="__blank" className="resume-link" key={index}>
              <div className="resume-icon">{item.icon}</div>
            </a>
          ))}
        </div>
      </div>

      <main>{children}</main>
    </div>
  );
};

export default Sidebar;
