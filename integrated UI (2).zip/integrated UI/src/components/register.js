import { useState } from "react";
import axios from "axios";

import { Link, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Swal from "sweetalert2";
import draw2 from "../images/draw2.webp";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const myStyle = {
  color: "red",
  fontSize: "12px",
};

const Register = () => {
  const [employeeId, employeeIdChange] = useState("");
  const [firstName, firstnamechange] = useState("");
  const [lastName, lastnamechange] = useState("");
  const [password, passwordchange] = useState("");
  const [email, emailChange] = useState("");
  const navigate = useNavigate();

  const [employeeIdError, setEmployeeIdError] = useState("");
  const [firstNameError, setFirstNameError] = useState("");
  const [lastNameError, setLastNameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const isSmallScreen=window.innerWidth<768;

  const validateEmployeeId = () => {
    if ( employeeId === "") {
      setEmployeeIdError("Employee ID is required");
    } else if (!/^\d{5}$/.test(employeeId)) {
      setEmployeeIdError("Employee ID must be a 5-digit number");
    } else {
      setEmployeeIdError(null);
    }
  };

  const validateFirstName = () => {
    if (firstName === "" ) {
      setFirstNameError("First name is required");
    } else if (/[^a-zA-Z]/.test(firstName)) {
      setFirstNameError(
        "First name should not contain special characters or numbers"
      );
    } else {
      setFirstNameError("");
    }
  };

  const validateLastName = () => {
    if (lastName === "") {
      setLastNameError("Last name is required");
    } else if (/[^a-zA-Z]/.test(lastName)) {
      setLastNameError(
        "Last name should not contain special characters or numbers"
      );
    } else {
      setLastNameError("");
    }
  };

  const validateEmail = () => {
    if (email === "") {
      setEmailError("Email is required");
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(email)) {
      setEmailError("Enter a valid email address");
    } else {
      setEmailError("");
    }
  };

  const validatePassword = () => {
    if (password === "" || password.length < 5) {
      setPasswordError("Password must be at least 5 characters long");
    } else {
      setPasswordError("");
    }
  };

  const handlesubmit = (e) => {
    e.preventDefault();

    validateEmployeeId();
    validateFirstName();
    validateLastName();
    validateEmail();
    validatePassword();

    if (
      employeeIdError === null &&
      firstNameError === "" &&
      lastNameError === "" &&
      emailError === "" &&
      passwordError === ""
    ) {
      axios
        .post(
          "http://localhost:8085/employeeportal-service/employee_auth/signup",
          {
            employeeId: employeeId,
            firstName: firstName,
            lastName: lastName,
            email: email,
            password: password,
          }
        )
        .then((response) => {
          Swal.fire("Registered successfully.");
          navigate("/login");
        })
        .catch((err) => {
          toast.error("Failed :" + err.response.data);
        });
    }
  };

  return (
    <div>
      <div>
        <Navbar />
      </div>
      <div
        className="row"
        style={{
          fontFamily: "Roboto",
          height: "100vh",
          margin: "0",
          paddingBottom: "20px",
          overflow: "auto",
          backgroundColor: "#04b1d9 ",
         
        }}
      >
        <div
          className="col-md-9 col-lg-6 col-xl-5"
          style={{ marginTop: "100px" }}
        >
        {!isSmallScreen && 
          <img src={draw2} className="img-fluid" alt="image" />}
        </div>
        <div
          className="col-md-8 col-lg-6 col-xl-4 offset-xl-2"
          style={{ marginTop: "100px" }}
        >
          <form className="container" onSubmit={handlesubmit}>
            <div
              className="card"
              style={{
                boxShadow:
                  "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
              }}
            >
              <div
                className="card-header"
                style={{ fontWeight: "lighter", fontSize: "5px" }}
              >
                <h1> Register </h1>
              </div>
              <div className="card-body">
                <div className="row">
                  <div className="col-lg-6">
                    <div className="form-group">
                      <label>
                        Employee Id{" "}
                        <span className="errmsg" style={myStyle}>
                          *
                        </span>
                      </label>
                      <input
                        // required
                        value={employeeId}
                        // min="10000"
                        // max="99999"
                        onChange={(e) => employeeIdChange(e.target.value)}
                        type="number"
                        className="form-control"
                        onBlur={validateEmployeeId}
                        style={{ borderColor: employeeIdError ? "red" : "" }}
                      ></input>
                      {employeeIdError && (
                        <p className="error" style={myStyle}>
                          {employeeIdError}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="col-lg-6">
                    <div className="form-group">
                      <label>
                        First Name{" "}
                        <span className="errmsg" style={myStyle}>
                          *
                        </span>
                      </label>
                      <input
                        type="text"
                        // required
                        value={firstName}
                        // pattern="^[A-Za-z.\\s]+$"
                        placeholder="eg: john"
                        onChange={(e) => firstnamechange(e.target.value)}
                        className="form-control"
                        onBlur={validateFirstName}
                        style={{ borderColor: firstNameError ? "red" : "" }}
                      ></input>
                      {firstNameError && (
                        <p className="error" style={myStyle}>
                          {firstNameError}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="col-lg-6">
                    <div className="form-group">
                      <label>
                        Last Name{" "}
                        <span className="errmsg" style={myStyle}>
                          *
                        </span>
                      </label>
                      <input
                        type="text"
                        placeholder="eg: wick"
                        value={lastName}
                        // required
                        // pattern="^[A-Za-z.\\s]+$"
                        onChange={(e) => lastnamechange(e.target.value)}
                        className="form-control"
                        onBlur={validateLastName}
                        style={{ borderColor: lastNameError ? "red" : "" }}
                      ></input>
                      {lastNameError && (
                        <p className="error" style={myStyle}>
                          {lastNameError}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="col-lg-6">
                    <div className="form-group">
                      <label>
                        Email{" "}
                        <span className="errmsg" style={myStyle}>
                          *
                        </span>
                      </label>
                      <input
                        type="email"
                        // required
                        value={email}
                        placeholder="eg: user@abc.com"
                        onChange={(e) => emailChange(e.target.value)}
                        className="form-control"
                        onBlur={validateEmail}
                        style={{ borderColor: emailError ? "red" : "" }}
                      ></input>
                      {emailError && (
                        <p className="error" style={myStyle}>
                          {emailError}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="col-lg-6">
                    <div className="form-group">
                      <label>
                        Password{" "}
                        <span className="errmsg" style={myStyle}>
                          *
                        </span>
                      </label>
                      <input
                        type="password"
                        // required
                        value={password}
                        // minLength={5}
                        onChange={(e) => passwordchange(e.target.value)}
                        className="form-control"
                        onBlur={validatePassword}
                        style={{ borderColor: passwordError ? "red" : "" }}
                      ></input>
                      {passwordError && (
                        <p className="error" style={myStyle}>
                          {passwordError}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="card-footer">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
                <Link
                  to={"/login"}
                  className="btn btn-danger"
                  style={{ marginLeft: "8px" }}
                >
                  Close
                </Link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
export default Register;
