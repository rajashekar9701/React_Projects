import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
const PersonalInfo = () => {
  return (
    <>
      <Navbar />
      <div>
      <h1>PersonInfo</h1>
      </div>
      {/* <Footer /> */}
    </>
  );
};

export default PersonalInfo;
