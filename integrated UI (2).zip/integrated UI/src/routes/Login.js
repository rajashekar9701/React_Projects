import React, { useState } from "react";
import { NavLink } from "react-router-dom";

import { useNavigate, Link } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import axios from "axios";
import Swal from "sweetalert2";
import { toast } from "react-toastify";
import draw2 from "../images/draw2.webp";

const myStyle={
  color:"red",
  fontSize:'12px'
}

const Login = () => {
  const [email, emailUpdate] = useState("");
  const [password, passwordUpdate] = useState("");
  let token;
  let userEmail;
  const navigate = useNavigate();
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const validateEmail = () => {
    if (email === "") {
      setEmailError("Email is required");
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(email)) {
      setEmailError("Enter a valid email address");
    } else {
      setEmailError("");
    }
  };

  const validatePassword = () => {
    if (password === "" || password.length < 5) {
      setPasswordError("Wrong password");
    } else {
      setPasswordError("");
    }
  };

  const ProceedLogin = (e) => {
    const credentials = {
      email,
      password,
    };
    validateEmail();
    validatePassword();
    e.preventDefault();
    if (emailError === "" && passwordError === "") {
      axios
        .post(
          "http://localhost:8085/employeeportal-service/employee_auth/signin",
          credentials
        )
        .then((res) => {
          token = res.data.jwtToken;
          userEmail = res.data.userName;
          localStorage.setItem("jwtToken", token);
          localStorage.setItem("email", userEmail);
          Swal.fire("Login Successful");
          navigate("/");
        })
        .catch((err) => {
          toast.error("Invalid credentials / User not found!");
          console.log(err);
        });
    }
  };
  return (
    <div>
      <Navbar />
      <div
        className="row vh-100"
        style={{
          height: "100%",
          width:"100%",
          backgroundSize:"cover",
          // opacity: 0.5,
          // position: "",
          top: 0,
          left: 0,
          // paddingBottom: "20px",
          overflow: "scroll",
          margin: "0 0 10px",
          backgroundColor: "#04b1d9",
          display:"flex",
          justifyContent:"center",
          flexDirection:"row"
         

          // backgroundRepeat:'no-repeat'
        }}
      >
        <div
          className="col-md-9 col-lg-6 col-xl-5 d-sm-none d-md-none d-lg-block"
          style={{ marginTop: "80px" }}
        >
          <img src={draw2} className="img-fluid" alt="Sample image" />
        </div>
        <div
          className="col-md-8 col-lg-6 col-xl-4 offset-xl-1"
          style={{ marginTop: "100px" }}
        >
          <form onSubmit={ProceedLogin} className="container">
            <div
              className="card"
              style={{
                boxShadow:
                  "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
                backgroundColor: "white",
              }}
            >
              <div className="card-header">
                <h2>User Login</h2>
              </div>
              <div className="card-body">
                <div className="form-group mb-2">
                  <label>
                    Email <span className="errmsg" style={myStyle}>*</span>
                  </label>
                  <input
                    value={email}
                    onChange={(e) => emailUpdate(e.target.value)}
                    className="form-control"
                    // required
                    onBlur={validateEmail}
                        style={{borderColor:emailError? 'red':''}}
                  ></input>
                  {emailError && <p className="error" style={myStyle}>{emailError}</p>}
                </div>
                <div className="form-group mb-2">
                  <label>
                    Password <span className="errmsg" style={myStyle}>*</span>
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => passwordUpdate(e.target.value)}
                    className="form-control"
                    // required
                    onBlur={validatePassword}
                        style={{borderColor:passwordError? 'red':''}}
                  ></input>
                   {passwordError && <p className="error" style={myStyle}>{passwordError}</p>}
                </div>
              </div>
              <div className="card-footer">
                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ border: "2px solid" }}
                >
                  Login
                </button>
                <Link
                  className="btn btn-success"
                  to={"/register"}
                  style={{ border: "2px solid" }}
                >
                  New User
                </Link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
export default Login;
