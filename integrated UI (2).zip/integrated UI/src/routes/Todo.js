import { useNavigate } from "react-router-dom";
import React from "react";
import TodoList from "../components/todo/TodoList"
import Navbar from "../components/Navbar";

const Todo = () => {
  // const auth = useAuth();
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.clear()
    navigate("/");
  };
  return (
    <>
      <Navbar />
      <div>
        {/* Todo Page {auth.user} */}
       <TodoList/>
      </div>
    </>
  );
};

export default Todo;
