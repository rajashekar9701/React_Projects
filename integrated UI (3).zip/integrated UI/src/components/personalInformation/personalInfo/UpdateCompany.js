import React, { useState, useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import CompanyService from "../services/CompanyService";
import Navbar from "../../Navbar"

const AddCompanyComponent = () => {
  const [employeeId, setEmployeeId] = useState("");

  const [title, setTitle] = useState("");
  const [managerName, setManagerName] = useState("");
  const [workPhone, setWorkPhone] = useState("");
  const [workLocation, setWorkLocation] = useState("");
  let [joiningDate, setJoiningDate] = useState("");
  const navigate = useNavigate();
  const { id } = useParams();

  const saveOrUpdateCompany = (e) => {
    console.log(id);

    console.log(joiningDate);
    var dateSplit = joiningDate.split("-");
    var sampleDate = dateSplit[2] + "-" + dateSplit[1] + "-" + dateSplit[0];
    console.log(sampleDate);
    joiningDate = sampleDate;

    e.preventDefault();

    const company = {
      employeeId,
      title,
      managerName,
      workPhone,
      workLocation,
      joiningDate,
    };

   
      CompanyService.updateCompany(id, company)
        .then((response) => {
          navigate(`/companyDetails`);
        })
        .catch((error) => {
          console.log(error);
        });
    // } else {
    //   CompanyService.createCompany(company)
    //     .then((response) => {
    //       console.log(response.data);

    //       //   navigate(`/${response.data.employeeId}`);
    //       navigate(`/`);
    //     })
    //     .catch((error) => {
    //       console.log(error);
    //     });
    // }
  };

  useEffect(() => {
    const email = localStorage.getItem("email");
    console.log(email);
    CompanyService.getCompanyById(email)
      .then((response) => {
        console.log(response);
        setEmployeeId(response.data.employeeId);
        setTitle(response.data.title);
        setManagerName(response.data.managerName);
        setWorkPhone(response.data.workPhone);
        setWorkLocation(response.data.workLocation);
        console.log(response.data.joiningDate);
        if (response.data.joiningDate != null) {
          let datePlit = response.data.joiningDate.split("-");
          setJoiningDate(datePlit[2] + "-" + datePlit[1] + "-" + datePlit[0]);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const title1 = () => {
    if (id) {
      return <h2 className="text-center">Update Company Details</h2>;
    } else {
      return <h2 className="text-center">Fill Company Details</h2>;
    }
  };

  return (
    <div>
      <Navbar />
      <br />
      <br />
      <div className="container">
        <div className="row">
          <div className="card col-md-6 offset-md-3 offset-md-3">
            {title1()}

            <div className="card-body">
              <form onSubmit={saveOrUpdateCompany}>
                <div className="form-group mb-2">
                  <label className="form-label">Employee Id<span className="errmsg" style={{color:"red"}}>*</span> :</label>
                  <input
                    type="number"  min="10000" max="99999"
                    placeholder="Enter employee Id "
                    name="employeeId"
                    className="form-control"
                    value={employeeId}
                    required
                    onChange={(e) => setEmployeeId(e.target.value)}
                    disabled
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label">Title<span className="errmsg" style={{color:"red"}}>*</span> : </label>
                  <input
                    type="text"
                    placeholder="Enter first name"
                    name="title"
                    pattern="^[A-Za-z.\\s]+$"
                    className="form-control"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label">Manager<span className="errmsg" style={{color:"red"}}>*</span> : </label>
                  <input
                    type="text"
                    placeholder="Enter  Manager name"
                    required
                    name="manager"
                    className="form-control"
                    value={managerName}
                    pattern="^[A-Za-z.\\s]+$"
                    required
                    onChange={(e) => setManagerName(e.target.value)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label">Work Phone Number<span className="errmsg" style={{color:"red"}}>*</span> :</label>
                  <input
                    type="tel"
                    placeholder="Enter work phone number"
                    pattern="[0-9]{10}"
                    name="workPhoneNumber"
                    className="form-control"
                    value={workPhone}
                    required
                    onChange={(e) => setWorkPhone(e.target.value)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label"> Work Location<span className="errmsg" style={{color:"red"}}>*</span> :</label>
                  <input
                    type="text"
                    placeholder="Enter work location "
                    name="workLocation"
                    className="form-control"
                    value={workLocation}
                    pattern="^[A-Za-z.\\s]+$"
                    required
                    onChange={(e) => setWorkLocation(e.target.value)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label"> start Date<span className="errmsg" style={{color:"red"}}>*</span> :</label>
                  <input
                    type="date"
                    placeholder="Enter your joining date"
                    required
                    name="startDate"
                    className="form-control"
                    value={joiningDate}
                    onChange={(e) => setJoiningDate(e.target.value)}
                  ></input>
                </div>

                <button
                  className="btn btn-success"
                 type="submit"
                >
                  Submit{" "}
                </button>
                <Link to={`/CompanyDetails`} className="btn btn-danger">
                  {" "}
                  Cancel{" "}
                </Link>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddCompanyComponent;
