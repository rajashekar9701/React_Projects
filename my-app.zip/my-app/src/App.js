import './App.css';
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom'; 
// import FooterComponent from './components/FooterComponent';
import HeaderComponent from './components/HeaderComponent';
import ListEmployeeComponent from './components/ListEmployeeComponent';
 import AddEmployeeComponent from './components/AddEmployeeComponent';
 import CompanyComponent from './components/Company.js'
import UpdateEmployeeComponent from './components/UpadateEmployeeComponent';
import UpdateCompanyComponent from './components/UpdateCompanyComponent';
import AddCompanyComponent from './components/AddCompanyComponents'
function App() {
  return (
    <div>
      <Router>
        <HeaderComponent />
        <div className= "container">
          <Routes>
          <Route  path = "/" exact element = {<ListEmployeeComponent/>}></Route>
              <Route  path = "/:id"  element = {<ListEmployeeComponent/>}></Route>
              <Route path = "/employees" element = {<ListEmployeeComponent/>}></Route>
                {/* <Route path = "/add-employee" element = {<AddEmployeeComponent/>} ></Route>  */} 
                <Route path = "/edit-employee/:id" element = {<AddEmployeeComponent/>}></Route>
                <Route path = "/edit-company/:id" element = {<AddCompanyComponent/>}></Route>

                <Route path = "/add-company/:id" element = {<UpdateCompanyComponent/>}></Route>
                <Route path = "/edit-company" element = {<AddCompanyComponent/>}></Route>
                


                {/* <Route path = "/add-employee/:id" element = {<CompanyComponent/>} ></Route>  */}
                {/* <Route path="/edit-company/:id" element ={<AddCompanyComponent/>}</Route> */}
                {/* <Route path = "/update-company/:id" element = {<UpdateCompanyComponent/>}></Route> */}
                {/* <Route path = "/companys" element = {<CompanyComponent/>}></Route> */}
              <Route path = "/add-employee/:id" element = {<CompanyComponent/>} ></Route>   
            {/* <Route path = "/add-company/:id" element = {<CompanyComponent/>} ></Route>   */}
          
            

            </Routes>
        </div>
        {/* <FooterComponent /> */}
        </Router>
    </div>
  );
}

export default App;