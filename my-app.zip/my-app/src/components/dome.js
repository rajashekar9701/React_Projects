import React from 'react'

const dome = () => {
  return (
    <div>
      
    </div>
  )
}

export default dome
