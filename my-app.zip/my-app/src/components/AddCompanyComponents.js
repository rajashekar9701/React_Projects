import React, {useState, useEffect} from 'react'
import {Link, useNavigate, useParams } from 'react-router-dom';
import CompanyService from '../services/CompanyService'

const AddCompanyComponent = () => {
    
     const [title, setTitle]= useState('')
    const[ managerName, setManagerName] = useState('')
    const [workPhone, setWorkPhone] = useState('')
    const [workLocation, setWorkLocation]= useState('')
    const [joiningDate, setJoiningDate]= useState('')
    const navigate =useNavigate();
    const {id}=useParams()

    const saveOrUpdateCompany= (e) => {
      console.log(id);
        e.preventDefault();

        const company = {title, managerName, workPhone, workLocation, joiningDate}

        if(id){
            CompanyService.updateCompany(id, company).then((response) => {
               navigate(`/${id}`)
            }).catch(error => {
                console.log(error)
            })

        }else{
           CompanyService.createCompany(company).then((response) =>{

                console.log(response.data)
    
              navigate('/Company');
    
            }).catch(error => {
                console.log(error)
            })
        }
        
    }

    useEffect(() => {

      CompanyService.getCompanyById(id).then((response) =>{
            setTitle(response.data.title)
            setManagerName(response.data.managerName)
            setWorkPhone(response.data.workPhone)
            setWorkLocation(response.data.workLocation)
            console.log(response.data.joiningDate)
            setJoiningDate(new Date(response.data.joiningDate))
        }).catch(error => {
            console.log(error)
        })
    }, [])

    const title1= () => {

        if(id){
            return <h2 className = "text-center">Update Company Details</h2>
        }else{
            return <h2 className = "text-center">Add Employee</h2>
        }
    }

    return (
        <div>
           <br /><br />
           <div className = "container">
                <div className = "row">
                    <div className = "card col-md-6 offset-md-3 offset-md-3">
                       {
                           title1()
                       }
                        <div className = "card-body">
                            <form>
                                <div className = "form-group mb-2">
                                    <label className = "form-label">Title :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter first name"
                                        name = "title" required
                                        pattern="^[A-Za-z.\\s]+$"
                                        className = "form-control"
                                        value = {title}
                                        onChange = {(e) => setTitle(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label">Manager :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter  Manager name"
                                        name = "manager"
                                        className = "form-control"
                                        pattern="^[A-Za-z.\\s]+$"
                                        value = {managerName}
                                        onChange = {(e) => setManagerName(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label">Work Phone Number:</label>
                                    <input
                                        type = "number"
                                        placeholder = "Enter work phone number"
                                        name = "workPhoneNumber"
                                        className = "form-control"
                                        value = {workPhone}
                                        // pattern="/^\d{10}$/"
                                        onChange = {(e) => setWorkPhone(e.target.value)}
                                    >
                                    </input>
                                </div>
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Work Location :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter work location "
                                        name = "workLocation"  required
                                        className = "form-control"
                                        value = {workLocation}
                                        onChange = {(e) => setWorkLocation(e.target.value)} 
                                    >
                                    </input>
                                </div>
                               
                               
                                
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> start Date :</label>
                                    <input
                                        type = "date"
                                        placeholder = "Enter your joining date"
                                        name = "startDate"
                                        className = "form-control"
                                        value = {joiningDate}
                                        required
                                        onChange = {(e) => setJoiningDate(e.target.value)}
                                    >
                                    </input>
                                </div>
                               

                                <button className = "btn btn-success" onClick = {(e) => saveOrUpdateCompany(e)} >Submit </button>
                                <Link to="/" className="btn btn-danger"> Cancel </Link>
                            </form>

                        </div>
                    </div>
                </div>

           </div>

        </div>
    )
}

export default AddCompanyComponent;