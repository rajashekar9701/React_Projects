import React, { Component } from 'react'
import EmployeeService from '../services/EmployeeService';
class UpdateEmployeeComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            firstName: '',
            lastName: '',
            email: '',

            address:'',
            phoneNo:'',
            alternatePhoneNo:'',
            personalEmail  :'',
            governmentId:'',
            birthDate:'',
        }
        this.changefirstNameHandler = this.changefirstNameHandler.bind(this);
        this.changelastNameHandler = this.changelastNameHandler.bind(this);

        this.changepersonalEmailHandler = this.changepersonalEmailHandler.bind(this);
        this.changeaddressHandler = this.changeaddressHandler.bind(this);
        this.changephoneNoHandler = this.changephoneNoHandler.bind(this);
         this.changegovernmentIdHandler = this.changegovernmentIdHandler.bind(this);
        this.changebirthDateHandler = this.changebirthDateHandler.bind(this);
        this.changealternatePhoneNoHandler = this.changealternatePhoneNoHandler.bind(this);

        this.updateEmployee = this.updateEmployee.bind(this);
    }

    componentDidMount(){
        EmployeeService.getEmployeeById(this.state.id).then( (res) =>{
            let employee = res.data;
            this.setState({firstName: employee.firstName,
                lastName: employee.lastName,
                email : employee.email,

                personalEmail: employee.personalEmail,
                 address : employee.address ,
                phoneNumber: employee.phoneNumber,
               personalPhoneNo : employee.personalPhoneNo,
                birthDate : employee.birthDate,
                governmentId: employee.governmentId,

            });
            
           
              
        });
    }

    updateEmployee = (e) => {
        e.preventDefault();
        let employee = {firstName: this.state.firstName, lastName: this.state.lastName, email: this.state.email,
            personalEmail: this.satate.personalEmail,   address:this.state.address, phoneNo: this.state.phoneNo,  personalPhoneNo:this.state.personalPhoneNo, birthDate: this.state.  birthDate ,  governmentId: this.state.governmentId};
        console.log('employee => ' + JSON.stringify(employee));
        console.log('id => ' + JSON.stringify(this.state.id));
        EmployeeService.updateEmployee(employee, this.state.id).then( res => {
            this.props.history.push('/employees');
        });
    }
    
    changeFirstNameHandler= (event) => {
        this.setState({firstName: event.target.value});
    }

    changeLastNameHandler= (event) => {
        this.setState({lastName: event.target.value});
    }

    changeEmailHandler= (event) => {
        this.setState({email: event.target.value});
    }

    changePersonalEmailHandler= (event) => {
        this.setState({personalEmail: event.target.value});
    }
    changeAddressHandler= (event) => {
        this.setState({address: event.target.value});
    }

    changePhoneNoHandler= (event) => {
        this.setState({phoneNo: event.target.value});
    }

    changeGovernmentIdHandler= (event) => {
        this.setState({governmentId: event.target.value});
    }

    changeBirthDateHandler= (event) => {
        this.setState({birthDate: event.target.value});
    }

    changeAlternatePhoneNoHandler= (event) => {
        this.setState({alternatePhoneNo: event.target.value});
    }


    cancel(){
        this.props.history.push('/employees');
    }

    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center">Update Employee</h3>
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> First Name: </label>
                                            <input placeholder="First Name" name="firstName" className="form-control" 
                                                value={this.state.firstName} onChange={this.changeFirstNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Last Name: </label>
                                            <input placeholder="Last Name" name="lastName" className="form-control" 
                                                value={this.state.lastName} onChange={this.changeLastNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Email Id: </label>
                                            <input placeholder="Email Address" name="emailId" className="form-control" 
                                                value={this.state.email} onChange={this.changeEmailHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label>Personal Email Id: </label>
                                            <input placeholder="Personal Email Id" name="personal_email_id" className="form-control" 
                                                value={this.state.personalEmail} onChange={this.changepersonalEmailHandler}/>
                                        </div>

                                        <div className = "form-group">
                                            <label> Address:</label>
                                            <input placeholder=" Address" name="address" className="form-control" 
                                                value={this.state.address} onChange={this.changeaddressHandler}/>
                                        </div>

                                         <div className = "form-group">
                                            <label> Date Of Birth </label>
                                            <input placeholder="Date of birth" name="emailId" className="form-control" 
                                                value={this.state.birthDate} onChange={this.changebirthDateHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Phone Number: </label>
                                            <input placeholder="Email Address" name="emailId" className="form-control" 
                                                value={this.state.phoneNumber} onChange={this.changephoneNumberHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Alernate Phone Number</label>
                                            <input placeholder="Email Address" name="emailId" className="form-control" 
                                                value={this.state.alternatePhoneNo} onChange={this.changephoneNumberHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Governament Id: </label>
                                            <input placeholder="Email Address" name="emailId" className="form-control" 
                                                value={this.state.governmentId} onChange={this.changegovernmentHandler}/>
                                        </div>




                                        <button className="btn btn-success" onClick={this.updateEmployee}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default UpdateEmployeeComponent