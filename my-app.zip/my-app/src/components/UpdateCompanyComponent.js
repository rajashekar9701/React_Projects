import React, { Component } from "react";
import CompanyService from "../services/CompanyService";

class UpdateCompanyComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      id: this.props.match.params.id,
      title: "",
      manager: "",
      workLocation: "",
      workPhoneNumber: "",
      joiningDate: "",
    };
    this.changetitleHandler = this.changetitleHandler.bind(this);
    this.changemanagerHandler = this.changemanagerHandler.bind(this);
    this.changeworkPhoneNumberHandler =
      this.changeworkPhoneNumberHandler.bind(this);

    this.changestartDateHandler = this.changestartDateHandler.bind(this);

    this.updateCompany = this.updateCompany.bind(this);
  }

  componentDidMount() {
    console.log(this.state.id);
    CompanyService.getCompanyById(this.state.id).then((res) => {
      let company = res.data;
      console.log(company)
      this.setState({
        title: company.title,
        manager: company.manager,
        workPhoneNo: company.workPhoneNo,
        joiningDate: new Date(company.joiningDate),
      });
    });
  }

  updateCompany = (e) => {
    e.preventDefault();
    let company = {
      title: this.state.title,
      manager: this.state.manager,
      workPoneNumber: this.state.workPhoneNumber,
      joiningDate: this.state.joiningDate,
    };
    console.log("company => " + JSON.stringify(company));
    console.log("id => " + JSON.stringify(this.state.id));
    CompanyService.updateCompany(company, this.state.id).then((res) => {
      this.props.history.push("/companys");
    });
  };

  changeTitleHandler = (event) => {
    this.setState({ title: event.target.value });
  };

  changeManagerHandler = (event) => {
    this.setState({ manager: event.target.value });
  };

  changeWorkPhoneNumberHandler = (event) => {
    this.setState({ workPhoneNumber: event.target.value });
  };

  changeStartDateHandler = (event) => {
    this.setState({ joiningDate: event.target.value });
  };

  cancel() {
    this.props.history.push("/companys");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <h3 className="text-center">Update Employee</h3>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> Title: </label>
                    <input
                      placeholder="Title"
                      name="Title"
                      className="form-control"
                      value={this.state.title}
                      onChange={this.changeTitleHandler}
                    />
                  </div>
                  <div className="form-group">
                    <label>Manager: </label>
                    <input
                      placeholder="Manager"
                      name="manager"
                      className="form-control"
                      value={this.state.manager}
                      onChange={this.changemanagerHandler}
                    />
                  </div>
                  <div className="form-group">
                    <label> Work Phone Number: </label>
                    <input
                      placeholder="Work Phone Number"
                      name="emailId"
                      className="form-control"
                      value={this.state.workPhoneNumber}
                      onChange={this.changeWorkPhoneNumberHandler}
                    />
                  </div>
                  <div className="form-group">
                    <label>Work Location: </label>
                    <input
                      placeholder="Work Location"
                      name="work location"
                      className="form-control"
                      value={this.state.workLocation}
                      onChange={this.changeWorkLocationHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> start Date :</label>
                    <input
                      placeholder="Email Address"
                      name="emailId"
                      className="form-control"
                      value={this.state.startDate}
                      onChange={this.changestartDateHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.updateCompany}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default UpdateCompanyComponent;
