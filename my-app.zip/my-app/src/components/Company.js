import React, {useState, useEffect} from 'react'
import { Link } from 'react-router-dom'
import CompanyService from '../services/CompanyService'

import './table.css'
import './company.css'
import { useParams } from 'react-router-dom';

const CompanyComponent = () => {
    const {id} = useParams();
  

    const [companys, setCompanys] = useState([])

    useEffect(() => {
        getCompanyById(id);
        // getAllCompanys();
    }, [id])
    const getCompanyById = (employeeId) => {
       CompanyService.getCompanyById(employeeId).then((response) =>{
    
        setCompanys(response.data)
        
 
        }).catch(error =>{
            console.log(error);
        })
         
     }


    //  const getAllCompanys = () => {
    // CompanyService.getAllCompanys().then((response) => {
    //         setCompanys(response.data)
    //         console.log(response.data);
    //     }).catch(error =>{
    //         console.log(error);
    //     })
    // }
    //  const getCompanyById = (employeeId) => {
    //    CompanyService.getCompanyById(employeeId).then((response) =>{
    //     // setCompanys(response.data)
    //     //       console.log(response.data);
    //           getCompanyById();

    //    }).catch(error =>{
    //        console.log(error);
    //    })
        
    // }

    // const deleteCompany = (companyId) => {
    //    CompanyService.deleteCompany(companyId).then((response) =>{
    //     getAllCompanys();

    //    }).catch(error =>{
    //        console.log(error);
    //    })
        
    // }
   

    return (
        <div className = "container">
        <br></br>
            <h2 className = "text-center"> Company Details </h2><br></br>
                 <center>
          
            <table >
               
                   {/* <tr><th> Employee Id </th></tr> 
                  <tr> <th> Employee First Name </th></tr>
                   <tr> <th> Employee Last Name </th></tr>
                 <tr>  <th> Employee Email Id </th></tr>
                  <tr> <th> Employee Email Id </th></tr> */}
             
                    {/* <th> Actions </th>  */}
             
              
                    {
                   
                            <tr key = {companys.employeeId}> 
                           

                            <div className='st'>    <tr> <td>

                            
                               
                                    {/* <button className = "btn btn-danger" onClick = {() => deleteEmployee(employee.id)}
                                    style = {{marginLeft:"10px"}}> Delete</button> */}
                                </td></tr>
                               
                             <tr>  <th > Employee Id: </th>
                            <td> {companys.employeeId} </td></tr>
                            
                                <tr><th>Title:</th>
                                <td>{companys.title}</td></tr>

                                <tr>   <th>Manager  </th>
                                <td>{companys.managerName}</td></tr>
                               <tr>

                               <th>Work Location:</th>
                                <td>{companys.workLocation} </td></tr>
                                <tr>
                               <th> Work Phone Number:</th>
                                <td>{companys.workPhone} </td></tr>
                                
                                <tr>
                               <th> Joining Date:  </th>
                                <td>{companys.joiningDate} </td></tr>
                                </div>
                              <br></br>
                              <div className='st1'><Link className="btn btn-info" to={`/edit-company/${companys.employeeId}`} >Update</Link></div>
                            </tr>
                            
                        
                    }
              
            </table>
            </center>
        </div>
    )
}

export default CompanyComponent;