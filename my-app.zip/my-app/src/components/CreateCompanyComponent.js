import React, { Component } from 'react'
import CompanyService from '../services/CompanyService';

class CreateCompanyComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            id: this.props.match.params.id,
            title: '',
            manager: '',
            workLocation: '',
            workPhoneNumber: '',
            startDate:''
        }
        this.changeTitleHandler = this.changeTitleHandler.bind(this);
        this.changeManagerHandler = this.changeManagerHandler.bind(this);
        this.changeWorkLocationHandler = this.changeWorkLocationHandler.bind(this);
        this.changeWorkPhoneNumberHandler = this.changeWorkPhoneNumberHandler.bind(this);
        this.changeStartDateHandler = this.changeStartDateHandler.bind(this);
        this.saveOrUpdateCompany = this.saveOrUpdateCompany.bind(this);
    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.id === '_add'){
            return
        }else{
           CompanyService.getCompanyById(this.state.id).then( (res) =>{
                let company = res.data;
                this.setState({title: company.title,
                    manager: company.manager,
                   workLocation: company.worklocation,
                   workPhoneNumber: company.workPhoneNumber,
                   startDate:company.startDate
                });
            });
        }        
    }
    saveOrUpdateEmployee = (e) => {
        e.preventDefault();
        let company = {title: this.state.title, manager: this.state.manager, workLocation: this.state.workLocation, workPhoneNumber:this.state.workPhoneNumber,startdate:this.state.startDate};
        console.log('company => ' + JSON.stringify(company));

        // step 5
        if(this.state.id === '_add'){
            CompanyService.createCompany(company).then(res =>{
                this.props.history.push('/companys');
            });
        }else{
            CompanyService.updateCompany(company, this.state.id).then( res => {
                this.props.history.push('/companys');
            });
        }
    }
    
    changeTitleHandler= (event) => {
        this.setState({title: event.target.value});
    }

    changeManagerHandler= (event) => {
        this.setState({manager: event.target.value});
    }

    changeWorkLocationHandler= (event) => {
        this.setState({workLocation: event.target.value});
    }
    changeWorkPhoneNumberHandler= (event) => {
        this.setState({workPhoneNumber: event.target.value});
    }

    changeStartDateHandler= (event) => {
        this.setState({startDate: event.target.value});
    }


    cancel(){
        this.props.history.push('/companys');
    }

    getTitle(){
        if(this.state.id === '_add'){
            return <h3 className="text-center">Add Company</h3>
        }else{
            return <h3 className="text-center">Update company Details</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> Title: </label>
                                            <input placeholder="First Name" name="firstName" className="form-control" 
                                                value={this.state.title} onChange={this.changeTitleHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Manager: </label>
                                            <input placeholder="Manager" name="manager" className="form-control" 
                                                value={this.state.manager} onChange={this.changeManagerHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Work Location: </label>
                                            <input placeholder="Work Location" name="workLocation" className="form-control" 
                                                value={this.state.workLocation} onChange={this.changeworkLocationHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Work Phone Number </label>
                                            <input placeholder="Work Phone number" name="workPhoneNumber" className="form-control" 
                                                value={this.state.workPhoneNumber} onChange={this.changeworkPhoneNumberHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Start Date <Number></Number>: </label>
                                            <input placeholder="Start Date" name="startDate" className="form-control" 
                                                value={this.state.startDate} onChange={this.changestartDateHandler}/>
                                        </div>

                                        <button className="btn btn-success" onClick={this.saveOrUpdatecompany}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default CreateCompanyComponent