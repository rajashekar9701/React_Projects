import axios from 'axios';
import React, {useState, useEffect} from 'react'
import {Link, useNavigate, useParams } from 'react-router-dom';
import EmployeeService from '../services/EmployeeService'

const AddEmployeeComponent = () => {

    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')
    const [phoneNo, setPhoneNo]= useState('')
    const [alternatePhoneNo, setAlternatePhoneNo]= useState('')
    const [address, setAddress]= useState('')
    const [personalEmail, setPersonalEmail]= useState('')
    const [birthDate, setBirthDate]= useState('')
    const [governmentId, setGovernmentId]= useState('')
    const navigate = useNavigate();
    const {id} = useParams();
    console.log(id);
    const [phoneNumberError, setPhoneNumberError] = useState('');
    const [altPhoneNumberError, setAltPhoneNumberError] = useState('');


    const validatePhoneNumber = () => {
        const phoneNumberRegex = /^\d{10}$/; // Regex to match a 10-digit phone number
        if (!phoneNumberRegex.test(phoneNo)) {
        setPhoneNumberError('Please enter a valid 10-digit phone number');
        } else {
        setPhoneNumberError('');
        }
        };

        const validateAltPhoneNumber = () => {
            const phoneNumberRegex = /^\d{10}$/; // Regex to match a 10-digit phone number
            if (!phoneNumberRegex.test(alternatePhoneNo)) {
            setAltPhoneNumberError('Please enter a valid 10-digit alternate phone number');
            } else {
            setAltPhoneNumberError('');
            }
            };

    const handleSubmit = (e) => {
        e.preventDefault();
        validatePhoneNumber();
        validateAltPhoneNumber();
        // if(!phoneNumberError){
            
        // }
        
        const token=localStorage.getItem("jwtToken")
        const employee = {firstName, lastName, email, phoneNo, alternatePhoneNo, address, personalEmail, governmentId, birthDate}
    //   console.log(id);
     
        if(!phoneNumberError && !altPhoneNumberError){
            axios.put("http://localhost:8085/employeeportal-service/personalinfo"+id,{
            id,employee
        },
        {
            headers: {
                Authorization: 'Bearer ' + token
              }
        
            }).then((res)=>{
                navigate("/")
            }).catch(error => {
                 console.log(error)
            })
            // EmployeeService.updateEmployee(id, employee).then((response) => {
            //    navigate(`/${id}`)
            // }).catch(error => {
            //     console.log(error)
            // })

        }else{
            EmployeeService.createEmployee(employee).then((response) =>{

    
              navigate('/personalinfo');
    
            }).catch(error => {
                console.log(error)
            })
        }
        
    }
 

    useEffect(() => {

        EmployeeService.getEmployeeById(id).then((response) =>{
            setFirstName(response.data.firstName)
            setLastName(response.data.lastName)
            setEmail(response.data.email)
            setPhoneNo(response.data.phoneNo)
            setAlternatePhoneNo(response.data.alternatePhoneNo)
            setAddress(response.data.address)
            setGovernmentId(response.data.governmentId)
            setPersonalEmail(response.data.personalEmail)
            console.log(response.data.birthDate)
            setBirthDate(new Date(response.data.birthDate))

        }).catch(error => {
            console.log(error)
        })
    }, [])

    const title = () => {

        if(id){
            return <h2 className = "text-center">Update Personal Information</h2>
        }else{
            return <h2 className = "text-center">Add Employee</h2>
        }
    }

    return (
        <div>
           <br /><br />
           <div className = "container">
                <div className = "row">
                    <div className = "card col-md-6 offset-md-3 offset-md-3">
                       {
                           title()
                       }
                        <div className = "card-body">
                            <form onSubmit={handleSubmit}>
                            <div className='row'>
                            <div className="col-lg-6">
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> First Name : </label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter first name"
                                        name = "firstName"
                                        className = "form-control"
                                        value = {firstName}
                                        required
                                        pattern="^[A-Za-z.\\s]+$"
                                        onChange = {(e) => setFirstName(e.target.value)}
                                    >
                                    </input>
                                   
                                </div>
                                </div>
                                <div className="col-lg-6">
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Last Name : </label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter last name"
                                        name = "lastName"
                                        className = "form-control"
                                        value = {lastName}
                                        required
                                        pattern="^[A-Za-z.\\s]+$"
                                        onChange = {(e) => setLastName(e.target.value)}
                                    >
                                    </input>
                                    
                                </div>
                                </div>
                                <div className="col-lg-6">
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Email Id : </label>
                                    <input required
                                        type = "email"
                                        placeholder = "Enter email Id"
                                        name = "email"
                                        className = "form-control"
                                        value = {email}
                                        onChange = {(e) => setEmail(e.target.value)}
                                    >
                                    </input>
                                    
                                </div>
                                </div>
                                <div className="col-lg-6">
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Phone Number : </label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter Phone Number "
                                        name = "phoneNo"
                                        className = "form-control"
                                        value = {phoneNo}
                                        required
                                        // pattern='/^\d{10}$/'
                                        
                                        onChange = {(e) => setPhoneNo(e.target.value)}
                                    >
                                    </input>
                                    {phoneNumberError && <p style={{color:"red"}}>{phoneNumberError}</p>}
                                  
                                </div>
                                </div>
                                <div className="col-lg-6">
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Alternate Phone Number :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter Alternate Phone Number"
                                        name = "alternatPphoneNo"
                                        className = "form-control"
                                        value ={ alternatePhoneNo}
                                        onChange = {(e) => setAlternatePhoneNo(e.target.value)}
                                    >
                                    </input>
                                    {altPhoneNumberError && <p style={{color:"red"}}>{altPhoneNumberError}</p>}
                                    
                                </div>
                                </div>
                                <div className="col-lg-6">
                                <div className = "form-group mb-2">
                                    <label className = "form-label">Personal Email Id :</label>
                                    <input
                                        type = "email"
                                        placeholder = "Enter personal email Id"
                                        name = "personalEmail"
                                        className = "form-control"
                                        value = {personalEmail}
                                        onChange = {(e) => setPersonalEmail(e.target.value)}
                                    >
                                    </input>
                                </div>
                                </div>
                                <div className="col-lg-6">
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Address :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter Address"
                                        name = "address"
                                        className = "form-control"
                                        value = {address}
                                        onChange = {(e) => setAddress(e.target.value)}
                                    >
                                    </input>
                                </div>
                                </div>
                                <div className="col-lg-6">
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Birth Date :</label>
                                    <input
                                        type = "date"
                                        placeholder = "Enter your date of birth"
                                        name = "birthDate" required
                                        className = "form-control"
                                        value = {birthDate}
                                        onChange = {(e) => setBirthDate(e.target.value)}
                                    >
                                    </input>
                                </div>
                                </div>
                                </div>
                               


                                <button className = "btn btn-success" type="submit">Submit </button>
                                <Link to={`/${id}`} className="btn btn-danger"> Cancel </Link>
                            </form>

                        </div>
                    </div>
                </div>

           </div>

        </div>
    )
}

export default AddEmployeeComponent