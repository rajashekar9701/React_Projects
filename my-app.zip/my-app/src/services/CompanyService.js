import axios from 'axios'

const COMPANY_BASE_REST_API_URL = 'http://localhost:8085/employeeportal-service/companydetails';

class CompanyService{

    getAllCompanys(){
        return axios.get(COMPANY_BASE_REST_API_URL)
    }

    createCompany(company){
        return axios.post(COMPANY_BASE_REST_API_URL, company)
    }

    getCompanyById(employeeId){
       // console.log(employeeId);
        return axios.get(COMPANY_BASE_REST_API_URL + '/' + employeeId);
    }
  
    updateCompany(employeeId, company){
        return axios.put(COMPANY_BASE_REST_API_URL + '/' +employeeId, company);
    }

    deleteCompany(employeeId){
        return axios.delete(COMPANY_BASE_REST_API_URL + '/' +employeeId);
    }
}

export default new CompanyService();
