import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import EmployeeService from "../services/EmployeeService";
import "./table.css";
import "./company.css";
import Navbar from "../../Navbar"
import { useParams } from "react-router-dom";

const ListEmployeeComponent = () => {
  const { id } = useParams();

  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    getEmployeeById(id);

  }, [id]);
  const getEmployeeById = (employeeId) => {
    EmployeeService.getEmployeeById(employeeId)
      .then((response) => {
        console.log(response.data)
        setEmployees(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // const getAllEmployees = () => {
  //     EmployeeService.getAllEmployees().then((response) => {
  //         setEmployees(response.data)
  //         console.log(response.data);
  //     }).catch(error =>{
  //         console.log(error);
  //     })
  // }


  return (
    
    <div className="container">
     
     <Navbar />
      <table>
        {
        <tbody>
        <tr key={employees.employeeId}>
            <tr>
              <img src={require("./images.png")} />

              <td>
                <br></br>
                <h3>Personal Information</h3>
                <br></br>
                <Link
                  to={`/CompanyDetails`}
                  className="btn btn-info"
                >
                  Company details{" "}
                </Link>
                <Link
                  style={{ marginLeft: ".9rem" }}
                  className="btn btn-info"
                  to={`/edit-employee`} >Update</Link>
                  {/* to={`/edit-employee/${employees.employeeId}`} >Update</Link> */}
              </td>
              
            </tr>

            <tr style={{ bgcolor: "grey" }}>
              <th> Employee Id: </th>
              <td> {employees.employeeId} </td>
              <th>Address:</th>
              <td>{employees.address} </td>
            </tr>

            <tr>
              <th> First Name: </th>
              <td> {employees.firstName} </td>
              <th> Date of Birth:</th>
              <td>{employees.birthDate} </td>
            </tr>

            <tr>
              <th> Last Name: </th>
              <td>{employees.lastName}</td>
              <th> Phone Number:  </th>
              <td>{employees.phoneNo} </td>
            </tr>

            <tr>
              <th> Employee Email Id: </th>
              <td>{employees.email}</td>
              <th>Alternate Phone Number:  </th>
              <td>{employees.alternatePhoneNo} </td>
            </tr>

            <tr>
              <th>Personal Email Id: </th>
              <td>{employees.personalEmail}</td>
              <th> Government ID:</th>
              <td>{employees.governmentId} </td>
            </tr>
          </tr>
        </tbody>
         
        }
      </table>
    </div>
  );
};

export default ListEmployeeComponent;
