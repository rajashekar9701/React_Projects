import React, { useState, useEffect } from "react";

import { Link, useNavigate, useParams } from "react-router-dom";
import Navbar from "../../Navbar"
import EmployeeService from "../services/EmployeeService";

import axios from "axios";

const AddEmployeeComponent = () => {
  const [employeeId, setEmployeeId] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNo, setPhoneNo] = useState("");
  const [alternatePhoneNo, setAlternatePhoneNo] = useState("");
  const [address, setAddress] = useState("");
  const [personalEmail, setPersonalEmail] = useState("");
  let [birthDate, setBirthDate] = useState("");
  const [governmentId, setGovernmentId] = useState("");
  const navigate = useNavigate();
  const { id } = 1;
  console.log(id);

  const saveOrUpdateEmployee = (e) => {
    e.preventDefault();

    console.log(birthDate);
    var dateSplit = birthDate.split("-");
    var sampleDate = dateSplit[2] + "-" + dateSplit[1] + "-" + dateSplit[0];
    console.log(sampleDate);
    birthDate = sampleDate;

    // this.setState({birthDate:sampleDate})

    const employee = {
      employeeId,
      firstName,
      lastName,
      email,
      phoneNo,
      alternatePhoneNo,
      address,
      personalEmail,
      governmentId,
      birthDate,
    };
    console.log(employee);
    
    
      EmployeeService.updateEmployee(id, employee)
        .then((response) => {
          navigate(`/personalinfo`);
        })
        .catch((error) => {
          console.log(error);
        });
    // } else {
    //   EmployeeService.createEmployee(employee)
    //     .then((response) => {
    //       navigate(`/${response.data.employeeId}`);
    //     })
    //     .catch((error) => {
    //       console.log(error);
    //     });
    // }
  };

  useEffect(() => {
    EmployeeService.getEmployeeById(id)
      .then((response) => {
        setEmployeeId(response.data.employeeId);
        setFirstName(response.data.firstName);
        setLastName(response.data.lastName);
        setEmail(response.data.email);
        setPhoneNo(response.data.phoneNo);
        setAlternatePhoneNo(response.data.alternatePhoneNo);
        setAddress(response.data.address);
        setGovernmentId(response.data.governmentId);
        setPersonalEmail(response.data.personalEmail);
        console.log(response.data.birthDate);
        if (response.data.birthDate != null) {
          let datePlit = response.data.birthDate.split("-");
          setBirthDate(datePlit[2] + "-" + datePlit[1] + "-" + datePlit[0]);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const title = () => {
    if (id) {
      return <h2 className="text-center">Update Personal Information</h2>;
    } else {
      return <h2 className="text-center">Add Personal Information</h2>;
    }
  };

  return (
    <div>
      <Navbar />
      <br />
      <br />
      <div className="container">
        <div className="row">
          <div className="card col-md-6 offset-md-3 offset-md-3">
            {title()}
            <div className="card-body">
              <form onSubmit={saveOrUpdateEmployee}>
               
                
                    <div className="form-group mb-2">
                      <label className="form-label"> Employee Id  : *</label>

                      <input
                        type="number"
                        min="1000"
                        max="99999"
                        placeholder="Enter Employee Id"
                        name="employeeId"
                        required
                        className="form-control"
                        value={employeeId}
                        // onChange={(e) => setEmployeeId(e.target.value)}
                        disabled
                      ></input>
                    </div>
             

                  
                    <div className="form-group mb-2">
                      <label className="form-label"> First: *</label>

                      <input
                        type="text"
                        placeholder="Enter first name"
                        name="firstName"
                        className="form-control"
                        value={firstName}
                        required
                        pattern="^[A-Za-z.\\s]+$"
                        onChange={(e) => setFirstName(e.target.value)}
                      ></input>
                    </div>
             
 
                    <div className="form-group mb-2">
                      <label className="form-label"> Last Name  :*</label>
                       <input
                        type="text"
                        placeholder="Enter last name"
                        name="lastName"
                        className="form-control"
                        value={lastName}
                        required
                        pattern="^[A-Za-z.\\s]+$"
                        onChange={(e) => setLastName(e.target.value)}
                      ></input>
                    </div>
               

             
                    <div className="form-group mb-2">
                      <label className="form-label"> Email Id : *</label>

                      <input
                        type="email"
                        pattern=".+@globex\.com"
                        placeholder="Enter email Id (ex:abc@gmail.com)"
                        name="email"
                        className="form-control"
                        value={email}
                        required
                        // onChange={(e) => setEmail(e.target.value)}
                        disabled
                      ></input>
                    </div>
             

                    <div className="form-group mb-2">
                      <label className="form-label"> Phone Number: *</label>

                      <input
                        type="text"
                        placeholder="Enter Phone Number (ex:9823543211) "
                        name="phoneNo"
                        pattern="[0-9]{10}"
                        className="form-control"
                        value={phoneNo}
                        required
                        onChange={(e) => setPhoneNo(e.target.value)}
                      ></input>
                    </div>
              

         
                    <div className="form-group mb-2">
                      <label className="form-label">
                        {" "}
                        Alternate Phone Number :*
                      </label>

                      <input
                        type="text"
                        placeholder="Enter Alternate Phone Number (ex:9876543211)"
                        pattern="[0-9]{10}"
                        name="alternatPphoneNo"
                        className="form-control"
                        value={alternatePhoneNo}
                        required
                        onChange={(e) => setAlternatePhoneNo(e.target.value)}
                      ></input>
                    </div>
              

                    <div className="form-group mb-2">
                      <label className="form-label">Personal Email Id: *</label>

                      <input
                        type="email"
                        // pattern=".+@globex\.com"
                        placeholder="Enter personal email Id"
                        name="personalEmail"
                        className="form-control"
                        value={personalEmail}
                        required
                        onChange={(e) => setPersonalEmail(e.target.value)}
                      ></input>
                    </div>
              

             
                    <div className="form-group mb-2">
                      <label className="form-label"> Address: </label>

                      <input
                        type="text"
                        placeholder="Enter Address"
                        name="address"
                        required
                        className="form-control"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                      ></input>
                    </div>
              

                  <div className="form-group mb-2">
              
                      <label className="form-label"> GovernmentId: *</label>

                      <input
                        type="text"
                        placeholder="Enter Government Id "
                        name="governmentId"
                        className="form-control"
                        value={governmentId}
                        recquired
                        onChange={(e) => setGovernmentId(e.target.value)}
                      ></input>
                    </div>
               

      
                    <div className="form-group mb-2">
                      <label className="form-label"> Birth Date:  </label>

                      <input
                        type="date"
                        placeholder="Enter your date of birth"
                        name="birthDate"
                        className="form-control"
                        value={birthDate}
                        required
                        onChange={(e) => {
                          console.log("Selected Date :");

                          console.log(e.target.value);

                          setBirthDate(e.target.value);
                        }}
                      ></input>
                    </div>
                 

                <button
                  className="btn btn-success"
                 type="submit" >Submit{" "}
                </button> <Link to={`/PersonalInfo`} className="btn btn-danger"> Cancel
                </Link>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddEmployeeComponent;
