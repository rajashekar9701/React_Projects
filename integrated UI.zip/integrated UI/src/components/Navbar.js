import { Link, useNavigate, Navigate } from "react-router-dom";

import "./NavbarStyles.css";
import React, { useEffect, useState } from "react";

import Tippy from "@tippyjs/react";
import "tippy.js/dist/tippy.css";

import axios from "axios";

import Swal from "sweetalert2";

import {
  FaBars,
  FaTimes,
  FaHome,
  FaCheckCircle,
  FaUserAlt,
  FaBook,
  FaSignInAlt,
  FaSignOutAlt,
} from "react-icons/fa";

const Navbar = () => {
  const navigate = useNavigate();
  const [click, setClick] = useState("false");
  const handleClick = () => setClick(!click);
  const handleLogout = () => {
    const token=localStorage.getItem('jwtToken')
    const varEmail=localStorage.getItem('email')
    console.log("logged out");
    axios.post('http://localhost:8085/employeeportal-service/employee_auth/logout',
     {
       email: varEmail, //varEmail is a variable which holds the email
     },
     {
       headers: {
         Authorization: 'Bearer ' + token
       }
     })
      .then((res) => {
       localStorage.clear();
       Swal.fire("Logout Successful")
        navigate("/");
      })
      .catch((err) => console.log(err));
  };

  // useEffect(() => {
  //   const tokenExpirationTime = 10; // Token expiration time in seconds

  //   // Start the timer when the component mounts
  //   const timer = setTimeout(handleLogout, tokenExpirationTime * 1000);
   

  //   // Clear the timer when the component unmounts or when the token is manually cleared
  //   return () => clearTimeout(timer);
  // }, []);

  return (
    <div className="header">
      <Link to="/">
        <img
          className="logo"
          src="https://tse4.mm.bing.net/th/id/OIP.bTWaiIirNZvVO2UDJMBoHwAAAA?pid=ImgDet&rs=1"
        />
      </Link>
      <ul className={click ? "nav-menu active" : "nav-menu"}>
        <li className="nav-item ">
          <Tippy content="HOME">
            <Link to="/">
              <FaHome className="icons-nav" />
            </Link>
          </Tippy>
        </li>
        <li>
          <Tippy content="PERSONAL INFO">
            <Link to="/personalinfo" onClick={handleClick}>
              <FaUserAlt className="icons-nav" />
            </Link>
          </Tippy>
        </li>
        
        <li>
          <Tippy content="RESUME">
            <Link to="/viewResume" onClick={handleClick}>
              <FaBook className="icons-nav" />
            </Link>
          </Tippy>
        </li>

        <li>
          <Tippy content="TODO">
            <Link to="/todo" onClick={handleClick}>
              <FaCheckCircle className="icons-nav" />
            </Link>
          </Tippy>
          {/* <Todo isLoggedIn={this.props.isLoggedIn} /> */}
        </li>
        
        <li>
          {localStorage.getItem("jwtToken") == null && (
            <Tippy content="LOGIN">
              <Link to="/login" onClick={handleClick}>
                <FaSignInAlt className="icons-nav" />
              </Link>
            </Tippy>
          )}
          {localStorage.getItem("jwtToken") != null && (
            <Tippy content="LOGOUT">
              <a onClick={handleLogout}>
                <FaSignOutAlt className="icons-nav" />
              </a>
            </Tippy>
          )}
        </li>
      </ul>
      <div className="hamburger" onClick={handleClick}>
        {click ? (
          <FaTimes size={20} style={{ color: "black" }} />
        ) : (
          <FaBars size={20} style={{ color: "black" }} />
        )}
      </div>
    </div>
  );
};

export default Navbar;
