import './Footer.css';
import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
       <p>©2023 Hitech BU</p>
    </div>
  )
}

export default Footer
