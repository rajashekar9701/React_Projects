import React from "react";
import "./Benefits.css";
const Benefits = () => {
  return (
    <div className="benifits">
      <section className="section1">
        {" "}
        <h1 className="left-to-right">BENEFITS OF THE EMPLOYEE PORTAL</h1>
      </section>

      <div className="card-container">
        <div className="card-col">
          <h3>REMOTE ACCESSIBILITY</h3>
          <span></span>
          <img
            className="img"
            src="https://www.pockethrms.com/wp-content/uploads/2022/04/Remote-Accessibility-1.svg"
            alt="no image"
          />
          <span></span>
          <p>
            Ensuring that the employee portal is optimized for mobile devices allows employees to access it easily from their smartphones or tablets, increasing convenience and accessibility.
          </p>
        </div>
        <div className="card-col">
          <h3>EMPLOYEE ENGAGEMENT</h3>
          <span></span>
          <img
            className="img"
            src="https://www.pockethrms.com/wp-content/uploads/2022/04/Employee-Engagement-2.svg"
            alt="no image"
          />
          <span></span>
          <p>
          Employee portals often include self-service features that empower employees to perform various tasks independently. This can include updating personal information, submitting tasks, Uploading resume and Updating.
          </p>
        </div>
        <div className="card-col">
          <h3>SAVES PRODUCTIVE TIME</h3>
          <span></span>
          <img
            className="img"
            src="https://www.pockethrms.com/wp-content/uploads/2022/01/Saves-Productive-Time.jpg"
            alt="no image"
          />
          <span></span>
          <p>
          By providing quick and easy access to their information, Resume portal, and TODO lists, employee portals can significantly enhance productivity. Additionally, self-service features reduce the need for manual paperwork.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Benefits;
